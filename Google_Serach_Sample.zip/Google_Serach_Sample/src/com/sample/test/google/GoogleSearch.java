/**
 * 
 */
/**
 * @author SC00351054
 *
 */
package com.sample.test.google;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleSearch {
    public static void main(String[] args) throws Exception {
        // The Firefox driver supports javascript 
        WebDriver driver = new FirefoxDriver();        
        // Go to the Google Suggest home page
        driver.get("http://www.google.com/webhp?complete=1&hl=en");        
        // Enter the query string "Cheese"
        WebElement mainquery = driver.findElement(By.name("q"));
        mainquery.sendKeys("Tech Mahindra");
        // Sleep until the div we want is visible or 5 seconds is over
        WebDriverWait wait = new WebDriverWait(driver, 5);       
        //#rso > li:nth-child(4) > div:nth-child(1) > div:nth-child(1) > h3:nth-child(1) > a:nth-child(1)
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/div/h3/a")));
        List<WebElement> subquery = driver.findElements(By.xpath("//div/div/h3/a"));
        subquery.get(0).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/a/img")));
        driver.quit();
    }
}